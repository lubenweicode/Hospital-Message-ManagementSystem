delimiter //
create procedure addAppointment(in p_patient_id varchar(50),in p_doctor_id varchar(50),in p_appointment_status tinyint,in p_appointment_symptoms varchar(255))
begin
    declare t_schedule_id varchar(50);
    select schedule_id into t_schedule_id from schedules where  doctor_id=p_doctor_id;
    insert into appointments (patient_id, doctor_id, schedule_id, appointment_status, symptoms) values
    (p_patient_id,p_doctor_id,t_schedule_id,p_appointment_status,p_appointment_symptoms);

    update schedules set current_patients=current_patients+1 where t_schedule_id=schedule_id;
end //

delimiter //
create procedure getAppointment(in p_patient_name varchar(50),in p_doctor_name varchar(50),in p_app_status tinyint)
begin
    declare d_id varchar(50);
    declare p_id varchar(50);
    select doctor_id from doctors where doctor_name=p_doctor_name;
    select patient_id from patients where patient_name=p_patient_name;
    select * from appointments where doctor_id=d_id and patient_id=p_id and appointment_status=p_app_status;
end //